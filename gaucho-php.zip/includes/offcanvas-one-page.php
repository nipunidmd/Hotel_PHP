  <div id="offcanvas" class="uk-offcanvas">
    <div class="uk-offcanvas-bar uk-offcanvas-bar-flip">
      <ul class="uk-nav uk-nav-parent-icon uk-nav-offcanvas" data-uk-nav>

        <li>
          <a href="#tm-container">Home</a>
        </li>
        <li>
          <a href="#tm-top-a">About Us</a>
        </li>
        <li>
          <a href="#tm-top-b"><i class="uk-icon-cutlery"></i> Offers</a>
        </li>
        <li>
          <a href="#tm-top-c">Menu</a>
        </li>
        <li>
          <a href="#tm-bottom-c">Location</a>
        </li>
        <li>
          <a href="#tm-bottom-d">Reservations</a>
        </li>
        <li>
          <a href="?page=blog">Blog</a>
        </li>
      </ul>
    </div>
  </div>