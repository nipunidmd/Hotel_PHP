  <div class="tm-toolbar uk-clearfix">

    <!-- toolbar left -->
    <div class="uk-float-left">
      <div>
        <ul class="uk-subnav uk-subnav-line">
          <li><a href="http://bit.ly/2LlU54F" target="_blank">Buy Now</a></li>
          <li><a href="#">Login</a></li>
        </ul>
      </div>

      <div class=" uk-hidden-small">
        <p>Open daily: 7:30 am to 11:00 pm</p>
      </div>
    </div>

    <!-- toolbar right -->
    <div class="uk-float-right">

      <div>
        <a href="https://www.dribbble.com/arrowthemes" class="uk-icon-button uk-icon-dribbble" target="_blank"></a>
        <a href="https://www.facebook.com/arrowthemes" class="uk-icon-button uk-icon-facebook" target="_blank"></a>
        <a href="https://www.twitter.com/arrowthemes" class="uk-icon-button uk-icon-twitter" target="_blank"></a>
      </div>
    </div>
  </div>