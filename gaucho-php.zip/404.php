<body style="background-position: 50% 0px; background-image:url(images/background/bg-image-12.jpg)" data-uk-parallax="{bg: '-200'}">

<!-- menu bar -->
<?php include("includes/nav.php"); ?>

    <div class="uk-height-viewport uk-cover-background uk-vertical-align uk-text-center" style="margin-top: -65px">
      <div class="uk-vertical-align-middle uk-container-center uk-panel-box uk-panel-box-secondary">

        <i class="tm-error-icon uk-icon-7s-way"></i>
        <br>
        <h1 class="uk-h2 tm-error-headline">404</h1>
        <h3 class="uk-margin-large-top">Sorry we couldn't find that page</h2>

        <p>The Page you are looking for doesn't exist or an other error occurred.<br class="uk-hidden-small"> <a href="javascript:history.go(-1)">Go back</a>, or head over to <a href="?page=home">Gaucho</a> to choose a new direction.</p>

      </div>
    </div>
